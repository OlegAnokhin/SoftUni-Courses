import { getSearchResult } from '../api/searchBonus.js';
import { html } from '../lib.js';

const searchTemp = (makeSearch, result) => html`
    <section id="search">
        <h2>Search by Brand</h2>
    
        <form @submit=${makeSearch} class="search-wrapper cf">
            <input id="#search-input" type="text" name="search" placeholder="Search here..." required />
            <button type="submit">Search</button>
        </form>
    
        <h3>Results:</h3>
        <!-- <div id="search-container">
            ${result.length == 0 ? html`<h2>There are no results found.</h2>` 
            : result.map(findCard)}
        </div>    -->
    </section>`
const findCard = (item) => html`
    <div id="search-container">
        <ul class="card-wrapper">
            <!-- Display a li with information about every post (if any)-->
            <li class="card">
                <img src="./images/travis.jpg" alt="travis" />
                <p>
                    <strong>Brand: </strong><span class="brand">Air Jordan</span>
                </p>
                <p>
                    <strong>Model: </strong><span class="model">1 Retro High TRAVIS SCOTT</span>
                </p>
                <p><strong>Value:</strong><span class="value">2000</span>$</p>
                <a class="details-btn" href="">Details</a>
            </li>
        </ul>
    </div>`
export async function searchView(ctx) {
    const result = await getSearchResult()
    ctx.render(searchTemp(makeSearch, result));

    function makeSearch(event) {
        event.preventDefault();
        const formData = new FormData(event.target);

        // const pet = {
        //     name: formData.get('name'),
        //     breed: formData.get('breed'),
        //     age: formData.get('age'),
        //     weight: formData.get('weight'),
        //     image: formData.get('image')
        // };
        // if (pet.name == '' || pet.breed == '' || pet.age == '' || pet.weight == '' || pet.image == '') {
        //     return alert('All fields are requared!')
        // }
    }
}