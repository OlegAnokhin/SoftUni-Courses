import { get } from "./api.js";

export async function getSearchResult(query) {
    return get(`/data/shoes?where=brand%20LIKE%20%22${query}%22`)
}
