﻿using System;
using System.Text;
using System.Collections.Generic;

namespace Farm
{
    public class Cat : Animal
    {
        public void Meow()
        {
            Console.WriteLine("meowing…");
        }
    }
}
