﻿using System;
using System.Text;
using System.Collections.Generic;

namespace Farm
{
    public class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating…");
        }
    }
}
