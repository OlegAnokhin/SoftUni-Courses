﻿namespace _03.Telephony.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();

    }
}
