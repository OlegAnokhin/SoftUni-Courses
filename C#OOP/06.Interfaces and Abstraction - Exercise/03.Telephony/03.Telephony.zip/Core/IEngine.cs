﻿namespace _03.Telephony.Core
{
    public interface IEngine
    {
        void Start();
    }
}
