﻿namespace _06.FoodShortage.Interfaces
{
using System;
    public interface IBirthable
    {
        DateTime Birthdate { get; }
    }
}