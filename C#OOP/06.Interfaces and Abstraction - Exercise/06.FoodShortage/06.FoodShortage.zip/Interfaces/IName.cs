﻿namespace _06.FoodShortage.Interfaces
{
    public interface IName
    {
        string Name { get; }
    }
}
