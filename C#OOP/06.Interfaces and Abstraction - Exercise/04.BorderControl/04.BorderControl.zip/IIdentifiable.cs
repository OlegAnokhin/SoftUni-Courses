﻿namespace _04.BorderControl
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
