﻿using System;
using System.Text;
using System.Collections.Generic;

namespace _05.BirthdayCelebrations.Interfaces
{
    public interface IName
    {
        string Name { get; }
    }
}
