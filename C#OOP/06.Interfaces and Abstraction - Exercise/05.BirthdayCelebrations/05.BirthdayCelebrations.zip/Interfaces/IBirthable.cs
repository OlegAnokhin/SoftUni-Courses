﻿namespace _05.BirthdayCelebrations.Interfaces
{
using System;
    public interface IBirthable
    {
        DateTime Birthdate { get; }
    }
}