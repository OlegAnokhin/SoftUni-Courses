﻿namespace InterfacesAndAbstraction.Core
{
    public interface IEngine
    {
        public void Run();
    }
}