﻿using System;
using System.Text;
using System.Collections.Generic;
using PlanetWars.Models.Weapons.Contracts;

namespace PlanetWars.Models.Weapons
{
    public abstract class Weapon : IWeapon
    {
        private int destructionLevel;
        private double price;
        public Weapon(int destructionLevel, double price)
        {
            this.destructionLevel = destructionLevel;
            this.price = price;
        }

        public double Price => throw new NotImplementedException();
        public int DestructionLevel => throw new NotImplementedException();
    }
}