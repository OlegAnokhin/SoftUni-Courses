﻿using PlanetWars.Models.MilitaryUnits.Contracts;
using System;
using System.Text;
using System.Collections.Generic;

namespace PlanetWars.Models.MilitaryUnits
{
    public abstract class MilitaryUnit : IMilitaryUnit
    {
        private double cost;
        private int enduranceLevel = 1;
        public MilitaryUnit(double cost)
        {
            this.cost = cost;
            this.enduranceLevel = enduranceLevel;
        }
        public double Cost => throw new NotImplementedException();

        public int EnduranceLevel => throw new NotImplementedException();

        public void IncreaseEndurance()
        {
            throw new NotImplementedException();
        }
    }
}