﻿using System;
using System.Text;
using System.Collections.Generic;
using PlanetWars.Repositories.Contracts;
using PlanetWars.Models.MilitaryUnits.Contracts;

namespace PlanetWars.Repositories
{
    public class UnitRepository : IRepository<IMilitaryUnit>
    {
        private readonly ICollection<IMilitaryUnit> militaryUnits;
        public UnitRepository()
        {
            militaryUnits = new List<IMilitaryUnit>();
        }
        public IReadOnlyCollection<IMilitaryUnit> Models => throw new NotImplementedException();
        public void AddItem(IMilitaryUnit model)
        {
            throw new NotImplementedException();
        }
        public IMilitaryUnit FindByName(string name)
        {
            throw new NotImplementedException();
        }
        public bool RemoveItem(string name)
        {
            throw new NotImplementedException();
        }
    }
}