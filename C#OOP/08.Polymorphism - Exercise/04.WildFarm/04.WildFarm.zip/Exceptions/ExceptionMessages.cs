﻿namespace _04.WildFarm.Exceptions
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public static class ExceptionMessages
    {
        public const string FoodNotPreferred = "{0} does not eat {1}!";
    }
}