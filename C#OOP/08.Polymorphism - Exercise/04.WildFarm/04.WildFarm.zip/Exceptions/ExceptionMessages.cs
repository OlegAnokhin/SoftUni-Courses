﻿namespace _04.WildFarm.Exceptions
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class ExceptionMessages
    {
        public const string FoodNotPreferred = "{0} does not eat {1}!";
    }
}
