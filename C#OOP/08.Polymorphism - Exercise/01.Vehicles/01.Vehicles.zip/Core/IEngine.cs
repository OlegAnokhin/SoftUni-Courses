﻿namespace _01.Vehicles.Core
{
    public interface IEngine
    {
        void Start();
    }
}
