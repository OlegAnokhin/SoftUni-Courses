﻿namespace _03.Raiding
{
    using Core;
    using System;

    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Start();
        }
    }
}


//3
//Mike
//Paladin
//Josh
//Druid
//Scott
//Warrior
//250

//2
//Mike
//Warrior
//Tom
//Rogue
//200