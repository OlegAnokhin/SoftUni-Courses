﻿namespace _03.Raiding.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Druid : BaseHero
    {
        public Druid(string name) 
            : base(name, 80)
        {
        }
    }
}