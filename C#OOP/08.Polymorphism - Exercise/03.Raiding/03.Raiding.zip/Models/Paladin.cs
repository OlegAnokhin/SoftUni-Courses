﻿namespace _03.Raiding.Models
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Paladin : BaseHero
    {
        public Paladin(string name) 
            : base(name, 100)
        {
        }
    }
}
