﻿namespace _03.Raiding.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public interface ICastAbilitys
    {
        public string CastAbility();
    }
}
