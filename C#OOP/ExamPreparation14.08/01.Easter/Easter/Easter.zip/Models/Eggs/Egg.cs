﻿using System;
using System.Text;
using System.Collections.Generic;
using Easter.Models.Eggs.Contracts;

namespace Easter.Models.Eggs
{
    public class Egg : IEgg
    {
        private string name;
        private int energyRequired;
        public Egg(string name, int energyRequired)
        {
            this.name = name;
            this.energyRequired = energyRequired;
        }
        public string Name => throw new NotImplementedException();
        public int EnergyRequired => throw new NotImplementedException();
        public void GetColored()
        {
            throw new NotImplementedException();
        }
        public bool IsDone()
        {
            throw new NotImplementedException();
        }
    }
}