﻿using System;
using System.Text;
using System.Collections.Generic;
using Easter.Models.Workshops.Contracts;
using Easter.Models.Eggs.Contracts;
using Easter.Models.Bunnies.Contracts;

namespace Easter.Models.Workshops
{
    public class Workshop : IWorkshop
    {
        public void Color(IEgg egg, IBunny bunny)
        {
            throw new NotImplementedException();
        }
    }
}