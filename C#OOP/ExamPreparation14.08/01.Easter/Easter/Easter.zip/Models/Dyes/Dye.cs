﻿using Easter.Models.Dyes.Contracts;
using System;
using System.Text;
using System.Collections.Generic;

namespace Easter.Models.Dyes
{
    public class Dye : IDye
    {
        private int power;
        public Dye(int power)
        {
            this.power = power;
        }
        public int Power => throw new NotImplementedException();
        public void Use()
        {
            throw new NotImplementedException();
        }
        public bool IsFinished()
        {
            throw new NotImplementedException();
        }
    }
}