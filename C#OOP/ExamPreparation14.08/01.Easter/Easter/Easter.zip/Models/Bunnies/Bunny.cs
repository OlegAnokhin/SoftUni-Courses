﻿using System;
using System.Text;
using System.Collections.Generic;
using Easter.Models.Bunnies.Contracts;
using Easter.Models.Dyes.Contracts;

namespace Easter.Models.Bunnies
{
    public abstract class Bunny : IBunny
    {
        private string name;
        private int energy;
        private readonly ICollection<IDye> dyes;
        public Bunny(string name, int energy)
        {
            this.name = name;
            this.energy = energy;
            this.dyes = new List<IDye>();
        }
        public string Name => throw new NotImplementedException();
        public int Energy => throw new NotImplementedException();
        public ICollection<IDye> Dyes => throw new NotImplementedException();
        public abstract void Work();
        public void AddDye(IDye dye)
        {
            throw new NotImplementedException();
        }
    }
}