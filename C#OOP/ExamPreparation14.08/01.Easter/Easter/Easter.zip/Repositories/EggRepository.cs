﻿using System;
using System.Text;
using System.Collections.Generic;
using Easter.Models.Eggs.Contracts;
using Easter.Repositories.Contracts;

namespace Easter.Repositories
{
    public class EggRepository : IRepository<IEgg>
    {
        private readonly ICollection<IEgg> eggs;
        public EggRepository()
        {
            eggs = new List<IEgg>();
        }
        public IReadOnlyCollection<IEgg> Models => throw new NotImplementedException();
        public void Add(IEgg model)
        {
            throw new NotImplementedException();
        }
        public IEgg FindByName(string name)
        {
            throw new NotImplementedException();
        }
        public bool Remove(IEgg model)
        {
            throw new NotImplementedException();
        }
    }
}