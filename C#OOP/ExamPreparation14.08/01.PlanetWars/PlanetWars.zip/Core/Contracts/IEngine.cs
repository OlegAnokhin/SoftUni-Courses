﻿namespace PlanetWars.Core.Contracts
{
    interface IEngine
    {
        void Run();
    }
}
