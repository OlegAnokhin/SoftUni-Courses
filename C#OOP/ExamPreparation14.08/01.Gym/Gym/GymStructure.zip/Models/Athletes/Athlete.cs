﻿using Gym.Models.Athletes.Contracts;
using System;
using System.Text;
using System.Collections.Generic;

namespace Gym.Models.Athletes
{
    public abstract class Athlete : IAthlete
    {
        private string fullName;
        private string motivation;
        private int stamina;
        private int numberOfMedals;
        public Athlete(string fullName, string motivation, int stamina, int numberOfMedals)
        {
            this.fullName = fullName;
            this.motivation = motivation;
            this.stamina = stamina;
            this.numberOfMedals = numberOfMedals;
        }

        public string FullName => throw new NotImplementedException();

        public string Motivation => throw new NotImplementedException();

        public int Stamina => throw new NotImplementedException();

        public int NumberOfMedals => throw new NotImplementedException();

        public abstract void Exercise();
    }
}
