﻿using System;
using System.Text;
using System.Collections.Generic;

namespace Gym.Models.Gyms
{
    public class BoxingGym : Gym
    {
        private const int boxinGymCapacity = 15;
        public BoxingGym(string name) 
            : base(name, boxinGymCapacity)
        {
        }
    }
}