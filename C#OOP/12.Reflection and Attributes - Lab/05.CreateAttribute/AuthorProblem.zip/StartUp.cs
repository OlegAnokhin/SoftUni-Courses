﻿namespace AuthorProblem
{
    using System;
    [Author("Oleg")]
    public class StartUp
    {
        [Author("Oleg")]
        [Author("Gosho")]
        static void Main()
        {
        }
    }
}
//05.CreateAttribute