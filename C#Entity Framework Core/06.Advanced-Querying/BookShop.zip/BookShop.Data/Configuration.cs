﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            = @"Server=ACERPREDATOR\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
