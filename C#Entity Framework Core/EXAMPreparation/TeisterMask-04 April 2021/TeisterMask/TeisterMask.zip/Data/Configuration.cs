﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=ACERPREDATOR\SQLEXPRESS;Database=TeisterMaskExam;Integrated Security=True;Encrypt=False";
    }
}
