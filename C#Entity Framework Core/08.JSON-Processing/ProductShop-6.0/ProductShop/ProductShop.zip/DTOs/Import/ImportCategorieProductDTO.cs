﻿namespace ProductShop.DTOs.Import
{
    public class ImportCategorieProductDTO
    {
        public int CategoryId { get; set; }

        public int ProductId { get; set; }
    }
}
