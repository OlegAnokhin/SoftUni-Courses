﻿namespace ProductShop.DTOs.Import
{
    using Newtonsoft.Json;

    public class ImportCategorieProductDTO
    {
        public int CategoryId { get; set; }

        public int ProductId { get; set; }
    }
}
