﻿namespace ProductShop
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Collections.Generic;
    using AutoMapper;
    using Newtonsoft.Json;

    using Data;
    using Models;
    using DTOs.Import;

    public class StartUp
    {
        public static void Main()
        {
            //Query1
            //ProductShopContext context = new ProductShopContext();
            //string inputString = File.ReadAllText(@"../../../Datasets/users.json");

            //string result = ImportUsers(context, inputString);
            //Console.WriteLine(result);

            //Query2
            //ProductShopContext context = new ProductShopContext();
            //string inputString = File.ReadAllText(@"../../../Datasets/products.json");

            //string result = ImportProducts(context, inputString);
            //Console.WriteLine(result);

            //Query3
            //ProductShopContext context = new ProductShopContext();
            //string inputString = File.ReadAllText(@"../../../Datasets/categories.json");

            //string result = ImportCategories(context, inputString);
            //Console.WriteLine(result);

            //Query4
            //ProductShopContext context = new ProductShopContext();
            //string inputString = File.ReadAllText(@"../../../Datasets/categories-products.json");

            //string result = ImportCategoryProducts(context, inputString);
            //Console.WriteLine(result);

        }


        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            IMapper mapper = CreateMapper();

            ImportUserDTO[] userDtos = JsonConvert.DeserializeObject<ImportUserDTO[]>(inputJson);

            ICollection<User> validUsers = new HashSet<User>();

            foreach (var userDto in userDtos)
            {
                User user = mapper.Map<User>(userDto);
                validUsers.Add(user);
            }
            context.Users.AddRange(validUsers);
            context.SaveChanges();

            return $"Successfully imported {validUsers.Count}";
        }

        public static string ImportProducts(ProductShopContext context, string inputJson)
        {
            IMapper mapper = CreateMapper();

            ImportProductDTO[] productsDtos = JsonConvert.DeserializeObject<ImportProductDTO[]>(inputJson);

            Product[] products = mapper.Map<Product[]>(productsDtos);
            context.Products.AddRange(products);
            context.SaveChanges();
            return $"Successfully imported {products.Length}";
        }

        public static string ImportCategories(ProductShopContext context, string inputJson)
        {
            IMapper mapper = CreateMapper();

            ImportCategoryDTO[] categoryDtos = JsonConvert.DeserializeObject<ImportCategoryDTO[]>(inputJson);

            ICollection<Category> validCategories = new HashSet<Category>();
            foreach (var categoryDto in categoryDtos)
            {
                if (String.IsNullOrEmpty(categoryDto.Name))
                {
                    continue;
                }
                Category category = mapper.Map<Category>(categoryDto);
                validCategories.Add(category);
            }
            context.Categories.AddRange(validCategories);
            context.SaveChanges();
            return $"Successfully imported {validCategories.Count}";
        }

        public static string ImportCategoryProducts(ProductShopContext context, string inputJson)
        {
            IMapper mapper = CreateMapper();

            ImportCategorieProductDTO[] cpDtos = JsonConvert.DeserializeObject<ImportCategorieProductDTO[]>(inputJson);

            ICollection<CategoryProduct> validEntries = new HashSet<CategoryProduct>();

            foreach (ImportCategorieProductDTO cpDto in cpDtos)
            {
                //if (!context.Categories.Any(c => c.Id == cpDto.CategoryId) ||
                //    !context.Products.Any(p => p.Id == cpDto.ProductId))
                //{
                //    continue;
                //}
                CategoryProduct categoryProduct = mapper.Map<CategoryProduct>(cpDto);
                validEntries.Add(categoryProduct);
                
            }
            context.CategoriesProducts.AddRange(validEntries);
            context.SaveChanges();
            return $"Successfully imported {validEntries.Count}";
        }


        private static IMapper CreateMapper()
        {
            return new Mapper(new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(typeof(ProductShopProfile));
            }));
        }
    }
}