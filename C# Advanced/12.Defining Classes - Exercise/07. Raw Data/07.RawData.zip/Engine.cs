﻿using System;
using System.Text;
using System.Collections.Generic;

namespace _07.RawData
{
    public class Engine
    {
        public int Speed { get; set; }
        public int Power { get; set; }
    }
}
