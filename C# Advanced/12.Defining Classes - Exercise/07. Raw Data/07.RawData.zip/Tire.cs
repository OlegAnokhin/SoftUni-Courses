﻿using System;
using System.Text;
using System.Collections.Generic;

namespace _07.RawData
{
    public class Tire
    {
        public double Pressure { get; set; }
        public int Age { get; set; }
    }
}
