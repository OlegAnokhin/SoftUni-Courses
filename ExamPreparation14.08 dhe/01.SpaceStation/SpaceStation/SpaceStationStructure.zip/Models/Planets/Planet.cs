﻿using SpaceStation.Models.Planets.Contracts;
using System;
using System.Text;
using System.Collections.Generic;

namespace SpaceStation.Models.Planets
{
    public class Planet : IPlanet
    {
        private string name;
        private ICollection<Planet> planets;
        public Planet(string name)
        {
            this.name = name;
            planets = new List<Planet>();
        }
        public ICollection<string> Items => throw new NotImplementedException();

        public string Name => throw new NotImplementedException();
    }
}