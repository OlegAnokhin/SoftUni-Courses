﻿using SpaceStation.Models.Astronauts.Contracts;
using SpaceStation.Models.Bags.Contracts;
using System;
using System.Text;
using System.Collections.Generic;

namespace SpaceStation.Models.Astronauts
{
    public abstract class Astronaut : IAstronaut
    {
        private string name;
        private double oxygen;
        //private bool canBreath;
       // private ICollection<IBag> bags;
        public Astronaut(string name, double oxygen)
        {
            this.name = name;
            this.oxygen = oxygen;
       //     canBreath = false;
     //      bags = new List<IBag>();
        }
        public string Name => throw new NotImplementedException();

        public double Oxygen => throw new NotImplementedException();

        public bool CanBreath => throw new NotImplementedException();

        public IBag Bag => throw new NotImplementedException();

        public virtual void Breath()
        {
            throw new NotImplementedException();
        }
    }
}