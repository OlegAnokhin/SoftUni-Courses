﻿using System;
using System.Text;
using System.Collections.Generic;

namespace SpaceStation.Models.Astronauts
{
    public class Biologist : Astronaut
    {
        private const double defOxygen = 70.00;
        public Biologist(string name) 
            : base(name, defOxygen)
        {
        }
        public override void Breath()
        {
           // Oxygen -= 5;
        }
    }
}